﻿using System;

namespace Assignment1SQ
{
    class Program
    {
        static void Main(string[] args)
        {
            int option,side1, side2,side3;
            string optionString = string.Empty;
            do
            {
                Console.WriteLine("1.Enter Triangle Dimention");
                Console.WriteLine("2.Exit");
                optionString = Console.ReadLine();
            } while (!int.TryParse(optionString, out option));

            while (option != 2)
            {

                Console.Write("Enter side 1 of triangle:::");
                side1 = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter side 2 of triangle:::");
                side2 = Convert.ToInt32(Console.ReadLine());
                
                Console.Write("Enter side 3 of triangle:::");
                side3 = Convert.ToInt32(Console.ReadLine());

                string result = TriangleSolver.Analyze(side1, side2, side3);
                Console.WriteLine(result);

                Console.WriteLine("1.Enter Triangle Dimention");
                Console.WriteLine("2.Exit");
                option = Convert.ToInt32(Console.ReadLine());

            }
        }

        }
    }

