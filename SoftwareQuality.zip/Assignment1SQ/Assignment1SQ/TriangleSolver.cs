﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assignment1SQ
{
    public static class TriangleSolver
    {
        public static string Analyze(int side1, int side2, int side3)
        {
            string triangleType = string.Empty;
            int[] values = new int[3] { side1, side2, side3 };
            if (side1 <= 0 || side2 <= 0 || side3 <= 0)
            {
                triangleType = "Error";
            }
            else if (values.Distinct().Count() == 1)
            {
                triangleType = "Equilateral";
            }
            else if (values.Distinct().Count() == 2) 
            {
                triangleType = "Isosceles";
            }
            else if (values.Distinct().Count() == 3) 
            {
                triangleType = "Scalene";
            }
            else
            {
                triangleType = "Error";
            }
            return triangleType;
        }
    }
}
